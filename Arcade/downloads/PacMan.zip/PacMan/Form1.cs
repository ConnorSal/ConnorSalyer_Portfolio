namespace PacMan
{
    public partial class Form1 : Form
    {

        bool goup, godown, goleft, goright;
        bool noup, nodown, noleft, noright;
        List<PictureBox> walls = new List<PictureBox>();
        List<PictureBox> dots = new List<PictureBox>();
        int speed = 12;
        int score = 0;
        int totalScore = 0;
        int rounds = 0;

        Ghost red, yellow, blue, pink;
        List<Ghost> ghosts = new List<Ghost>();

        public Form1()
        {
            InitializeComponent();
            SetUp();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox22_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox66_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && !noleft)
            {
                goright = godown = goup = false;
                noright = nodown = noup = false;
                goleft = true;
                pacman.Image = Properties.Resources.PacmanLeft;
            }
            if (e.KeyCode == Keys.Right && !noright)
            {
                goleft = goup = godown = false;
                noleft = noup = nodown = false;
                goright = true;
                pacman.Image = Properties.Resources.PacmanRight;
            }
            if (e.KeyCode == Keys.Up && !noup)
            {
                goleft = goright = godown = false;
                noleft = noright = noup = false;
                goup = true;
                pacman.Image = Properties.Resources.PacmanUp;
            }
            if (e.KeyCode == Keys.Down && !nodown)
            {
                goleft = goright = goup = false;
                noleft = noright = noup = false;
                godown = true;
                pacman.Image = Properties.Resources.PacmanDown;
            }
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            PlayerMovements();

            foreach (PictureBox wall in walls)
            {
                CheckBoundries(pacman, wall);
            }

            foreach (PictureBox dot in dots)
            {
                CollectingDots(pacman, dot);
            }

            if (score == dots.Count())
            {
                ShowDots();
                score = 0;
                rounds++;
            }

            red.GhostMovement(pacman);
            blue.GhostMovement(pacman);
            yellow.GhostMovement(pacman);
            pink.GhostMovement(pacman);

            foreach (Ghost ghost in ghosts)
            {
                GhostCollision(ghost, pacman, ghost.image);
            }
        }

        private void StartButtonClick(object sender, EventArgs e)
        {
            lblInfo.Font = new Font(lblInfo.Font.FontFamily, 32, FontStyle.Regular);

            //disables and makes the menu panel invisible when the Start Button is clicked.
            panelMenu.Enabled = false;
            panelMenu.Visible = false;

            goleft = goright = goup = godown = false;
            noleft = noright = noup = nodown = false;
            score = 0;

            red.image.Location = new Point(100, 100);
            blue.image.Location = new Point(848, 597);
            yellow.image.Location = new Point(132, 584);
            pink.image.Location = new Point(877, 130);

            GameTimer.Start();
        }

        private void SetUp()
        {
            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && x.Tag == "wall")
                {
                    walls.Add((PictureBox)x);
                }
                if (x is PictureBox && x.Tag == "dot")
                {
                    dots.Add((PictureBox)x);
                }
            }

            red = new Ghost(this, Properties.Resources.blinky, 100,100);  //numbers determine ghosts spawn position, if you change them, you have to change them in the StartButtonClick as well
            ghosts.Add(red);
            blue = new Ghost(this, Properties.Resources.inky, 848, 597);
            ghosts.Add(blue);
            yellow = new Ghost(this, Properties.Resources.clyde, 132, 584);
            ghosts.Add(yellow);
            pink = new Ghost(this, Properties.Resources.pinky, 877, 130);
            ghosts.Add(pink);
        }

        private void PlayerMovements()
        {
            //basic movement
            if (goleft) { pacman.Left -= speed; }
            if (goright) { pacman.Left += speed; }
            if (goup) { pacman.Top -= speed; }
            if (godown) { pacman.Top += speed; }

            //make pacman appear on other side after going through opening in wall.
            //left/right
            if (pacman.Left < -30)
            {
                pacman.Left = this.ClientSize.Width - pacman.Width;
            }
            if (pacman.Left + pacman.Width > this.ClientSize.Width)
            {
                pacman.Left = -10;
            }
            //up/down
            if (pacman.Top < -30)
            {
                pacman.Top = this.ClientSize.Height - pacman.Height;
            }
            if (pacman.Top + pacman.Width > this.ClientSize.Height)
            {
                pacman.Top = -10;
            }
        }

        private void ShowDots()
        {
            foreach (PictureBox dot in dots)
            {
                dot.Visible = true;
            }
        }

        private void CheckBoundries(PictureBox pacman, PictureBox wall)
        {
            //wall collision
            if (pacman.Bounds.IntersectsWith(wall.Bounds))
            {
                if (goleft)
                {
                    noleft = true;
                    goleft = false;
                    pacman.Left = wall.Right + 2;
                }
                if (goright)
                {
                    noright = true;
                    goright = false;
                    pacman.Left = wall.Left - pacman.Width - 2;
                }
                if (goup)
                {
                    noup = true;
                    goup = false;
                    pacman.Top = wall.Bottom + 2;
                }
                if (godown)
                {
                    nodown = true;
                    godown = false;
                    pacman.Top = wall.Top - pacman.Height - 2;
                }
            }
        }

        private void CollectingDots(PictureBox pacman, PictureBox dot)
        {
            if (pacman.Bounds.IntersectsWith(dot.Bounds))
            {
                if (pacman.Bounds.IntersectsWith(dot.Bounds) && dot.Visible)
                {
                    dot.Visible = false;
                    score++;
                    totalScore++;
                }
            }
        }

        private void GhostCollision(Ghost g, PictureBox pacman, PictureBox ghost)
        {
            if (pacman.Bounds.IntersectsWith(ghost.Bounds))
            {
                GameOver();
                g.ChangeDirection();
            }
        }

        private void GameOver()
        {
            panelMenu.Visible = true;
            panelMenu.Enabled = true;
            GameTimer.Stop();
            ShowDots();
            pacman.Location = new Point(482, 340);

            lblInfo.Font = new Font(lblInfo.Font.FontFamily, 26, FontStyle.Bold);
            lblInfo.Text = $"LOSER!\n" +
                           $"Total Dots Collected: {totalScore}\n" +
                           $"Rounds Cleared: {rounds}";

            score = 0;
            totalScore = 0;
            rounds = 0;
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {

        }
    }
}
