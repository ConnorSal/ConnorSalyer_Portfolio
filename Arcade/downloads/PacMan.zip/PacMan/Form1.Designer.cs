﻿namespace PacMan
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pacman = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            pictureBox20 = new PictureBox();
            pictureBox21 = new PictureBox();
            pictureBox23 = new PictureBox();
            pictureBox25 = new PictureBox();
            pictureBox26 = new PictureBox();
            pictureBox28 = new PictureBox();
            pictureBox31 = new PictureBox();
            pictureBox32 = new PictureBox();
            pictureBox33 = new PictureBox();
            pictureBox34 = new PictureBox();
            pictureBox35 = new PictureBox();
            pictureBox36 = new PictureBox();
            pictureBox37 = new PictureBox();
            pictureBox38 = new PictureBox();
            pictureBox40 = new PictureBox();
            pictureBox73 = new PictureBox();
            pictureBox72 = new PictureBox();
            pictureBox71 = new PictureBox();
            pictureBox70 = new PictureBox();
            pictureBox69 = new PictureBox();
            pictureBox67 = new PictureBox();
            pictureBox42 = new PictureBox();
            pictureBox65 = new PictureBox();
            pictureBox63 = new PictureBox();
            pictureBox61 = new PictureBox();
            pictureBox60 = new PictureBox();
            pictureBox59 = new PictureBox();
            pictureBox58 = new PictureBox();
            pictureBox57 = new PictureBox();
            pictureBox56 = new PictureBox();
            pictureBox55 = new PictureBox();
            pictureBox54 = new PictureBox();
            pictureBox52 = new PictureBox();
            pictureBox50 = new PictureBox();
            pictureBox48 = new PictureBox();
            pictureBox46 = new PictureBox();
            pictureBox45 = new PictureBox();
            pictureBox44 = new PictureBox();
            pictureBox43 = new PictureBox();
            pictureBox74 = new PictureBox();
            pictureBox75 = new PictureBox();
            pictureBox76 = new PictureBox();
            pictureBox77 = new PictureBox();
            pictureBox78 = new PictureBox();
            pictureBox80 = new PictureBox();
            pictureBox82 = new PictureBox();
            pictureBox84 = new PictureBox();
            pictureBox86 = new PictureBox();
            pictureBox87 = new PictureBox();
            pictureBox88 = new PictureBox();
            pictureBox89 = new PictureBox();
            pictureBox90 = new PictureBox();
            pictureBox91 = new PictureBox();
            pictureBox92 = new PictureBox();
            pictureBox93 = new PictureBox();
            pictureBox95 = new PictureBox();
            pictureBox97 = new PictureBox();
            pictureBox99 = new PictureBox();
            pictureBox101 = new PictureBox();
            pictureBox102 = new PictureBox();
            pictureBox103 = new PictureBox();
            pictureBox104 = new PictureBox();
            pictureBox105 = new PictureBox();
            pictureBox106 = new PictureBox();
            pictureBox107 = new PictureBox();
            pictureBox108 = new PictureBox();
            pictureBox109 = new PictureBox();
            pictureBox110 = new PictureBox();
            pictureBox112 = new PictureBox();
            pictureBox114 = new PictureBox();
            pictureBox116 = new PictureBox();
            pictureBox118 = new PictureBox();
            pictureBox119 = new PictureBox();
            pictureBox120 = new PictureBox();
            pictureBox121 = new PictureBox();
            pictureBox122 = new PictureBox();
            pictureBox123 = new PictureBox();
            pictureBox124 = new PictureBox();
            pictureBox125 = new PictureBox();
            pictureBox127 = new PictureBox();
            pictureBox129 = new PictureBox();
            pictureBox131 = new PictureBox();
            pictureBox133 = new PictureBox();
            pictureBox134 = new PictureBox();
            pictureBox135 = new PictureBox();
            pictureBox136 = new PictureBox();
            pictureBox137 = new PictureBox();
            pictureBox62 = new PictureBox();
            pictureBox68 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox16 = new PictureBox();
            pictureBox22 = new PictureBox();
            pictureBox24 = new PictureBox();
            pictureBox27 = new PictureBox();
            pictureBox29 = new PictureBox();
            pictureBox30 = new PictureBox();
            pictureBox39 = new PictureBox();
            pictureBox41 = new PictureBox();
            pictureBox47 = new PictureBox();
            pictureBox49 = new PictureBox();
            pictureBox51 = new PictureBox();
            pictureBox53 = new PictureBox();
            pictureBox64 = new PictureBox();
            pictureBox66 = new PictureBox();
            pictureBox79 = new PictureBox();
            pictureBox81 = new PictureBox();
            pictureBox83 = new PictureBox();
            pictureBox85 = new PictureBox();
            pictureBox94 = new PictureBox();
            pictureBox96 = new PictureBox();
            pictureBox98 = new PictureBox();
            pictureBox100 = new PictureBox();
            GameTimer = new System.Windows.Forms.Timer(components);
            panelMenu = new Panel();
            lblInfo = new Label();
            label1 = new Label();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pacman).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox65).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox75).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox76).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox77).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox78).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox80).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox82).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox84).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox86).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox87).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox88).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox89).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox90).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox91).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox92).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox93).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox95).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox97).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox99).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox101).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox102).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox103).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox104).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox105).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox106).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox107).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox108).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox109).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox110).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox112).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox114).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox116).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox118).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox119).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox120).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox121).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox122).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox123).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox124).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox125).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox127).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox129).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox131).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox133).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox134).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox135).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox136).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox137).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox79).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox81).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox83).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox85).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox94).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox96).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox98).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox100).BeginInit();
            panelMenu.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox2.Location = new Point(12, 448);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(35, 276);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            pictureBox2.Tag = "wall";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox3.Location = new Point(12, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(35, 276);
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            pictureBox3.Tag = "wall";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox1.Location = new Point(967, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(35, 276);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Tag = "wall";
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox4.Location = new Point(967, 448);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(35, 276);
            pictureBox4.TabIndex = 5;
            pictureBox4.TabStop = false;
            pictureBox4.Tag = "wall";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox5.Location = new Point(43, 695);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(377, 29);
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            pictureBox5.Tag = "wall";
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox6.Location = new Point(594, 695);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(373, 29);
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            pictureBox6.Tag = "wall";
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox7.Location = new Point(594, 12);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(373, 29);
            pictureBox7.TabIndex = 9;
            pictureBox7.TabStop = false;
            pictureBox7.Tag = "wall";
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.FromArgb(0, 0, 64);
            pictureBox8.Location = new Point(43, 12);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(377, 29);
            pictureBox8.TabIndex = 8;
            pictureBox8.TabStop = false;
            pictureBox8.Tag = "wall";
            // 
            // pacman
            // 
            pacman.Image = Properties.Resources.PacmanRight;
            pacman.Location = new Point(482, 340);
            pacman.Name = "pacman";
            pacman.Size = new Size(50, 50);
            pacman.SizeMode = PictureBoxSizeMode.StretchImage;
            pacman.TabIndex = 10;
            pacman.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Pellet;
            pictureBox10.Location = new Point(883, 81);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(20, 20);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 11;
            pictureBox10.TabStop = false;
            pictureBox10.Tag = "dot";
            pictureBox10.Click += pictureBox10_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.Pellet;
            pictureBox11.Location = new Point(883, 117);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(20, 20);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 12;
            pictureBox11.TabStop = false;
            pictureBox11.Tag = "dot";
            pictureBox11.Click += pictureBox11_Click;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.Pellet;
            pictureBox12.Location = new Point(847, 117);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(20, 20);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 14;
            pictureBox12.TabStop = false;
            pictureBox12.Tag = "dot";
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.Pellet;
            pictureBox13.Location = new Point(847, 81);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(20, 20);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 13;
            pictureBox13.TabStop = false;
            pictureBox13.Tag = "dot";
            // 
            // pictureBox15
            // 
            pictureBox15.Image = Properties.Resources.Pellet;
            pictureBox15.Location = new Point(810, 81);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(20, 20);
            pictureBox15.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 15;
            pictureBox15.TabStop = false;
            pictureBox15.Tag = "dot";
            // 
            // pictureBox17
            // 
            pictureBox17.Image = Properties.Resources.Pellet;
            pictureBox17.Location = new Point(774, 81);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(20, 20);
            pictureBox17.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox17.TabIndex = 17;
            pictureBox17.TabStop = false;
            pictureBox17.Tag = "dot";
            pictureBox17.Click += pictureBox17_Click;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = Properties.Resources.Pellet;
            pictureBox18.Location = new Point(629, 117);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(20, 20);
            pictureBox18.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox18.TabIndex = 26;
            pictureBox18.TabStop = false;
            pictureBox18.Tag = "dot";
            // 
            // pictureBox19
            // 
            pictureBox19.Image = Properties.Resources.Pellet;
            pictureBox19.Location = new Point(629, 81);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(20, 20);
            pictureBox19.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox19.TabIndex = 25;
            pictureBox19.TabStop = false;
            pictureBox19.Tag = "dot";
            // 
            // pictureBox20
            // 
            pictureBox20.Image = Properties.Resources.Pellet;
            pictureBox20.Location = new Point(665, 117);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(20, 20);
            pictureBox20.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox20.TabIndex = 24;
            pictureBox20.TabStop = false;
            pictureBox20.Tag = "dot";
            // 
            // pictureBox21
            // 
            pictureBox21.Image = Properties.Resources.Pellet;
            pictureBox21.Location = new Point(665, 81);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new Size(20, 20);
            pictureBox21.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox21.TabIndex = 23;
            pictureBox21.TabStop = false;
            pictureBox21.Tag = "dot";
            // 
            // pictureBox23
            // 
            pictureBox23.Image = Properties.Resources.Pellet;
            pictureBox23.Location = new Point(702, 81);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new Size(20, 20);
            pictureBox23.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox23.TabIndex = 21;
            pictureBox23.TabStop = false;
            pictureBox23.Tag = "dot";
            // 
            // pictureBox25
            // 
            pictureBox25.Image = Properties.Resources.Pellet;
            pictureBox25.Location = new Point(738, 81);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(20, 20);
            pictureBox25.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox25.TabIndex = 19;
            pictureBox25.TabStop = false;
            pictureBox25.Tag = "dot";
            // 
            // pictureBox26
            // 
            pictureBox26.Image = Properties.Resources.Pellet;
            pictureBox26.Location = new Point(774, 189);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new Size(20, 20);
            pictureBox26.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox26.TabIndex = 34;
            pictureBox26.TabStop = false;
            pictureBox26.Tag = "dot";
            // 
            // pictureBox28
            // 
            pictureBox28.Image = Properties.Resources.Pellet;
            pictureBox28.Location = new Point(810, 189);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new Size(20, 20);
            pictureBox28.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox28.TabIndex = 32;
            pictureBox28.TabStop = false;
            pictureBox28.Tag = "dot";
            // 
            // pictureBox31
            // 
            pictureBox31.Image = Properties.Resources.Pellet;
            pictureBox31.Location = new Point(847, 153);
            pictureBox31.Name = "pictureBox31";
            pictureBox31.Size = new Size(20, 20);
            pictureBox31.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox31.TabIndex = 29;
            pictureBox31.TabStop = false;
            pictureBox31.Tag = "dot";
            // 
            // pictureBox32
            // 
            pictureBox32.Image = Properties.Resources.Pellet;
            pictureBox32.Location = new Point(883, 189);
            pictureBox32.Name = "pictureBox32";
            pictureBox32.Size = new Size(20, 20);
            pictureBox32.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox32.TabIndex = 28;
            pictureBox32.TabStop = false;
            pictureBox32.Tag = "dot";
            // 
            // pictureBox33
            // 
            pictureBox33.Image = Properties.Resources.Pellet;
            pictureBox33.Location = new Point(883, 153);
            pictureBox33.Name = "pictureBox33";
            pictureBox33.Size = new Size(20, 20);
            pictureBox33.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox33.TabIndex = 27;
            pictureBox33.TabStop = false;
            pictureBox33.Tag = "dot";
            // 
            // pictureBox34
            // 
            pictureBox34.Image = Properties.Resources.Pellet;
            pictureBox34.Location = new Point(629, 189);
            pictureBox34.Name = "pictureBox34";
            pictureBox34.Size = new Size(20, 20);
            pictureBox34.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox34.TabIndex = 42;
            pictureBox34.TabStop = false;
            pictureBox34.Tag = "dot";
            // 
            // pictureBox35
            // 
            pictureBox35.Image = Properties.Resources.Pellet;
            pictureBox35.Location = new Point(629, 153);
            pictureBox35.Name = "pictureBox35";
            pictureBox35.Size = new Size(20, 20);
            pictureBox35.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox35.TabIndex = 41;
            pictureBox35.TabStop = false;
            pictureBox35.Tag = "dot";
            // 
            // pictureBox36
            // 
            pictureBox36.Image = Properties.Resources.Pellet;
            pictureBox36.Location = new Point(665, 189);
            pictureBox36.Name = "pictureBox36";
            pictureBox36.Size = new Size(20, 20);
            pictureBox36.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox36.TabIndex = 40;
            pictureBox36.TabStop = false;
            pictureBox36.Tag = "dot";
            // 
            // pictureBox37
            // 
            pictureBox37.Image = Properties.Resources.Pellet;
            pictureBox37.Location = new Point(665, 153);
            pictureBox37.Name = "pictureBox37";
            pictureBox37.Size = new Size(20, 20);
            pictureBox37.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox37.TabIndex = 39;
            pictureBox37.TabStop = false;
            pictureBox37.Tag = "dot";
            // 
            // pictureBox38
            // 
            pictureBox38.Image = Properties.Resources.Pellet;
            pictureBox38.Location = new Point(702, 189);
            pictureBox38.Name = "pictureBox38";
            pictureBox38.Size = new Size(20, 20);
            pictureBox38.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox38.TabIndex = 38;
            pictureBox38.TabStop = false;
            pictureBox38.Tag = "dot";
            // 
            // pictureBox40
            // 
            pictureBox40.Image = Properties.Resources.Pellet;
            pictureBox40.Location = new Point(738, 189);
            pictureBox40.Name = "pictureBox40";
            pictureBox40.Size = new Size(20, 20);
            pictureBox40.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox40.TabIndex = 36;
            pictureBox40.TabStop = false;
            pictureBox40.Tag = "dot";
            // 
            // pictureBox73
            // 
            pictureBox73.Image = Properties.Resources.Pellet;
            pictureBox73.Location = new Point(883, 517);
            pictureBox73.Name = "pictureBox73";
            pictureBox73.Size = new Size(20, 20);
            pictureBox73.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox73.TabIndex = 43;
            pictureBox73.TabStop = false;
            pictureBox73.Tag = "dot";
            // 
            // pictureBox72
            // 
            pictureBox72.Image = Properties.Resources.Pellet;
            pictureBox72.Location = new Point(883, 553);
            pictureBox72.Name = "pictureBox72";
            pictureBox72.Size = new Size(20, 20);
            pictureBox72.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox72.TabIndex = 44;
            pictureBox72.TabStop = false;
            pictureBox72.Tag = "dot";
            // 
            // pictureBox71
            // 
            pictureBox71.Image = Properties.Resources.Pellet;
            pictureBox71.Location = new Point(847, 517);
            pictureBox71.Name = "pictureBox71";
            pictureBox71.Size = new Size(20, 20);
            pictureBox71.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox71.TabIndex = 45;
            pictureBox71.TabStop = false;
            pictureBox71.Tag = "dot";
            // 
            // pictureBox70
            // 
            pictureBox70.Image = Properties.Resources.Pellet;
            pictureBox70.Location = new Point(847, 553);
            pictureBox70.Name = "pictureBox70";
            pictureBox70.Size = new Size(20, 20);
            pictureBox70.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox70.TabIndex = 46;
            pictureBox70.TabStop = false;
            pictureBox70.Tag = "dot";
            // 
            // pictureBox69
            // 
            pictureBox69.Image = Properties.Resources.Pellet;
            pictureBox69.Location = new Point(810, 517);
            pictureBox69.Name = "pictureBox69";
            pictureBox69.Size = new Size(20, 20);
            pictureBox69.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox69.TabIndex = 47;
            pictureBox69.TabStop = false;
            pictureBox69.Tag = "dot";
            // 
            // pictureBox67
            // 
            pictureBox67.Image = Properties.Resources.Pellet;
            pictureBox67.Location = new Point(774, 517);
            pictureBox67.Name = "pictureBox67";
            pictureBox67.Size = new Size(20, 20);
            pictureBox67.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox67.TabIndex = 49;
            pictureBox67.TabStop = false;
            pictureBox67.Tag = "dot";
            // 
            // pictureBox42
            // 
            pictureBox42.Image = Properties.Resources.Pellet;
            pictureBox42.Location = new Point(629, 625);
            pictureBox42.Name = "pictureBox42";
            pictureBox42.Size = new Size(20, 20);
            pictureBox42.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox42.TabIndex = 74;
            pictureBox42.TabStop = false;
            pictureBox42.Tag = "dot";
            // 
            // pictureBox65
            // 
            pictureBox65.Image = Properties.Resources.Pellet;
            pictureBox65.Location = new Point(738, 517);
            pictureBox65.Name = "pictureBox65";
            pictureBox65.Size = new Size(20, 20);
            pictureBox65.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox65.TabIndex = 51;
            pictureBox65.TabStop = false;
            pictureBox65.Tag = "dot";
            // 
            // pictureBox63
            // 
            pictureBox63.Image = Properties.Resources.Pellet;
            pictureBox63.Location = new Point(702, 517);
            pictureBox63.Name = "pictureBox63";
            pictureBox63.Size = new Size(20, 20);
            pictureBox63.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox63.TabIndex = 53;
            pictureBox63.TabStop = false;
            pictureBox63.Tag = "dot";
            // 
            // pictureBox61
            // 
            pictureBox61.Image = Properties.Resources.Pellet;
            pictureBox61.Location = new Point(665, 517);
            pictureBox61.Name = "pictureBox61";
            pictureBox61.Size = new Size(20, 20);
            pictureBox61.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox61.TabIndex = 55;
            pictureBox61.TabStop = false;
            pictureBox61.Tag = "dot";
            // 
            // pictureBox60
            // 
            pictureBox60.Image = Properties.Resources.Pellet;
            pictureBox60.Location = new Point(665, 553);
            pictureBox60.Name = "pictureBox60";
            pictureBox60.Size = new Size(20, 20);
            pictureBox60.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox60.TabIndex = 56;
            pictureBox60.TabStop = false;
            pictureBox60.Tag = "dot";
            // 
            // pictureBox59
            // 
            pictureBox59.Image = Properties.Resources.Pellet;
            pictureBox59.Location = new Point(629, 517);
            pictureBox59.Name = "pictureBox59";
            pictureBox59.Size = new Size(20, 20);
            pictureBox59.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox59.TabIndex = 57;
            pictureBox59.TabStop = false;
            pictureBox59.Tag = "dot";
            // 
            // pictureBox58
            // 
            pictureBox58.Image = Properties.Resources.Pellet;
            pictureBox58.Location = new Point(629, 553);
            pictureBox58.Name = "pictureBox58";
            pictureBox58.Size = new Size(20, 20);
            pictureBox58.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox58.TabIndex = 58;
            pictureBox58.TabStop = false;
            pictureBox58.Tag = "dot";
            // 
            // pictureBox57
            // 
            pictureBox57.Image = Properties.Resources.Pellet;
            pictureBox57.Location = new Point(883, 589);
            pictureBox57.Name = "pictureBox57";
            pictureBox57.Size = new Size(20, 20);
            pictureBox57.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox57.TabIndex = 59;
            pictureBox57.TabStop = false;
            pictureBox57.Tag = "dot";
            // 
            // pictureBox56
            // 
            pictureBox56.Image = Properties.Resources.Pellet;
            pictureBox56.Location = new Point(883, 625);
            pictureBox56.Name = "pictureBox56";
            pictureBox56.Size = new Size(20, 20);
            pictureBox56.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox56.TabIndex = 60;
            pictureBox56.TabStop = false;
            pictureBox56.Tag = "dot";
            // 
            // pictureBox55
            // 
            pictureBox55.Image = Properties.Resources.Pellet;
            pictureBox55.Location = new Point(847, 589);
            pictureBox55.Name = "pictureBox55";
            pictureBox55.Size = new Size(20, 20);
            pictureBox55.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox55.TabIndex = 61;
            pictureBox55.TabStop = false;
            pictureBox55.Tag = "dot";
            // 
            // pictureBox54
            // 
            pictureBox54.Image = Properties.Resources.Pellet;
            pictureBox54.Location = new Point(847, 625);
            pictureBox54.Name = "pictureBox54";
            pictureBox54.Size = new Size(20, 20);
            pictureBox54.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox54.TabIndex = 62;
            pictureBox54.TabStop = false;
            pictureBox54.Tag = "dot";
            // 
            // pictureBox52
            // 
            pictureBox52.Image = Properties.Resources.Pellet;
            pictureBox52.Location = new Point(810, 625);
            pictureBox52.Name = "pictureBox52";
            pictureBox52.Size = new Size(20, 20);
            pictureBox52.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox52.TabIndex = 64;
            pictureBox52.TabStop = false;
            pictureBox52.Tag = "dot";
            // 
            // pictureBox50
            // 
            pictureBox50.Image = Properties.Resources.Pellet;
            pictureBox50.Location = new Point(774, 625);
            pictureBox50.Name = "pictureBox50";
            pictureBox50.Size = new Size(20, 20);
            pictureBox50.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox50.TabIndex = 66;
            pictureBox50.TabStop = false;
            pictureBox50.Tag = "dot";
            // 
            // pictureBox48
            // 
            pictureBox48.Image = Properties.Resources.Pellet;
            pictureBox48.Location = new Point(738, 625);
            pictureBox48.Name = "pictureBox48";
            pictureBox48.Size = new Size(20, 20);
            pictureBox48.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox48.TabIndex = 68;
            pictureBox48.TabStop = false;
            pictureBox48.Tag = "dot";
            // 
            // pictureBox46
            // 
            pictureBox46.Image = Properties.Resources.Pellet;
            pictureBox46.Location = new Point(702, 625);
            pictureBox46.Name = "pictureBox46";
            pictureBox46.Size = new Size(20, 20);
            pictureBox46.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox46.TabIndex = 70;
            pictureBox46.TabStop = false;
            pictureBox46.Tag = "dot";
            // 
            // pictureBox45
            // 
            pictureBox45.Image = Properties.Resources.Pellet;
            pictureBox45.Location = new Point(665, 589);
            pictureBox45.Name = "pictureBox45";
            pictureBox45.Size = new Size(20, 20);
            pictureBox45.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox45.TabIndex = 71;
            pictureBox45.TabStop = false;
            pictureBox45.Tag = "dot";
            // 
            // pictureBox44
            // 
            pictureBox44.Image = Properties.Resources.Pellet;
            pictureBox44.Location = new Point(665, 625);
            pictureBox44.Name = "pictureBox44";
            pictureBox44.Size = new Size(20, 20);
            pictureBox44.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox44.TabIndex = 72;
            pictureBox44.TabStop = false;
            pictureBox44.Tag = "dot";
            // 
            // pictureBox43
            // 
            pictureBox43.Image = Properties.Resources.Pellet;
            pictureBox43.Location = new Point(629, 589);
            pictureBox43.Name = "pictureBox43";
            pictureBox43.Size = new Size(20, 20);
            pictureBox43.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox43.TabIndex = 73;
            pictureBox43.TabStop = false;
            pictureBox43.Tag = "dot";
            // 
            // pictureBox74
            // 
            pictureBox74.Image = Properties.Resources.Pellet;
            pictureBox74.Location = new Point(106, 189);
            pictureBox74.Name = "pictureBox74";
            pictureBox74.Size = new Size(20, 20);
            pictureBox74.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox74.TabIndex = 106;
            pictureBox74.TabStop = false;
            pictureBox74.Tag = "dot";
            // 
            // pictureBox75
            // 
            pictureBox75.Image = Properties.Resources.Pellet;
            pictureBox75.Location = new Point(106, 153);
            pictureBox75.Name = "pictureBox75";
            pictureBox75.Size = new Size(20, 20);
            pictureBox75.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox75.TabIndex = 105;
            pictureBox75.TabStop = false;
            pictureBox75.Tag = "dot";
            // 
            // pictureBox76
            // 
            pictureBox76.Image = Properties.Resources.Pellet;
            pictureBox76.Location = new Point(142, 189);
            pictureBox76.Name = "pictureBox76";
            pictureBox76.Size = new Size(20, 20);
            pictureBox76.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox76.TabIndex = 104;
            pictureBox76.TabStop = false;
            pictureBox76.Tag = "dot";
            // 
            // pictureBox77
            // 
            pictureBox77.Image = Properties.Resources.Pellet;
            pictureBox77.Location = new Point(142, 153);
            pictureBox77.Name = "pictureBox77";
            pictureBox77.Size = new Size(20, 20);
            pictureBox77.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox77.TabIndex = 103;
            pictureBox77.TabStop = false;
            pictureBox77.Tag = "dot";
            // 
            // pictureBox78
            // 
            pictureBox78.Image = Properties.Resources.Pellet;
            pictureBox78.Location = new Point(179, 189);
            pictureBox78.Name = "pictureBox78";
            pictureBox78.Size = new Size(20, 20);
            pictureBox78.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox78.TabIndex = 102;
            pictureBox78.TabStop = false;
            pictureBox78.Tag = "dot";
            // 
            // pictureBox80
            // 
            pictureBox80.Image = Properties.Resources.Pellet;
            pictureBox80.Location = new Point(215, 189);
            pictureBox80.Name = "pictureBox80";
            pictureBox80.Size = new Size(20, 20);
            pictureBox80.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox80.TabIndex = 100;
            pictureBox80.TabStop = false;
            pictureBox80.Tag = "dot";
            // 
            // pictureBox82
            // 
            pictureBox82.Image = Properties.Resources.Pellet;
            pictureBox82.Location = new Point(251, 189);
            pictureBox82.Name = "pictureBox82";
            pictureBox82.Size = new Size(20, 20);
            pictureBox82.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox82.TabIndex = 98;
            pictureBox82.TabStop = false;
            pictureBox82.Tag = "dot";
            // 
            // pictureBox84
            // 
            pictureBox84.Image = Properties.Resources.Pellet;
            pictureBox84.Location = new Point(287, 189);
            pictureBox84.Name = "pictureBox84";
            pictureBox84.Size = new Size(20, 20);
            pictureBox84.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox84.TabIndex = 96;
            pictureBox84.TabStop = false;
            pictureBox84.Tag = "dot";
            // 
            // pictureBox86
            // 
            pictureBox86.Image = Properties.Resources.Pellet;
            pictureBox86.Location = new Point(324, 189);
            pictureBox86.Name = "pictureBox86";
            pictureBox86.Size = new Size(20, 20);
            pictureBox86.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox86.TabIndex = 94;
            pictureBox86.TabStop = false;
            pictureBox86.Tag = "dot";
            // 
            // pictureBox87
            // 
            pictureBox87.Image = Properties.Resources.Pellet;
            pictureBox87.Location = new Point(324, 153);
            pictureBox87.Name = "pictureBox87";
            pictureBox87.Size = new Size(20, 20);
            pictureBox87.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox87.TabIndex = 93;
            pictureBox87.TabStop = false;
            pictureBox87.Tag = "dot";
            // 
            // pictureBox88
            // 
            pictureBox88.Image = Properties.Resources.Pellet;
            pictureBox88.Location = new Point(360, 189);
            pictureBox88.Name = "pictureBox88";
            pictureBox88.Size = new Size(20, 20);
            pictureBox88.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox88.TabIndex = 92;
            pictureBox88.TabStop = false;
            pictureBox88.Tag = "dot";
            // 
            // pictureBox89
            // 
            pictureBox89.Image = Properties.Resources.Pellet;
            pictureBox89.Location = new Point(360, 153);
            pictureBox89.Name = "pictureBox89";
            pictureBox89.Size = new Size(20, 20);
            pictureBox89.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox89.TabIndex = 91;
            pictureBox89.TabStop = false;
            pictureBox89.Tag = "dot";
            // 
            // pictureBox90
            // 
            pictureBox90.Image = Properties.Resources.Pellet;
            pictureBox90.Location = new Point(106, 117);
            pictureBox90.Name = "pictureBox90";
            pictureBox90.Size = new Size(20, 20);
            pictureBox90.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox90.TabIndex = 90;
            pictureBox90.TabStop = false;
            pictureBox90.Tag = "dot";
            // 
            // pictureBox91
            // 
            pictureBox91.Image = Properties.Resources.Pellet;
            pictureBox91.Location = new Point(106, 81);
            pictureBox91.Name = "pictureBox91";
            pictureBox91.Size = new Size(20, 20);
            pictureBox91.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox91.TabIndex = 89;
            pictureBox91.TabStop = false;
            pictureBox91.Tag = "dot";
            // 
            // pictureBox92
            // 
            pictureBox92.Image = Properties.Resources.Pellet;
            pictureBox92.Location = new Point(142, 117);
            pictureBox92.Name = "pictureBox92";
            pictureBox92.Size = new Size(20, 20);
            pictureBox92.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox92.TabIndex = 88;
            pictureBox92.TabStop = false;
            pictureBox92.Tag = "dot";
            // 
            // pictureBox93
            // 
            pictureBox93.Image = Properties.Resources.Pellet;
            pictureBox93.Location = new Point(142, 81);
            pictureBox93.Name = "pictureBox93";
            pictureBox93.Size = new Size(20, 20);
            pictureBox93.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox93.TabIndex = 87;
            pictureBox93.TabStop = false;
            pictureBox93.Tag = "dot";
            // 
            // pictureBox95
            // 
            pictureBox95.Image = Properties.Resources.Pellet;
            pictureBox95.Location = new Point(179, 81);
            pictureBox95.Name = "pictureBox95";
            pictureBox95.Size = new Size(20, 20);
            pictureBox95.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox95.TabIndex = 85;
            pictureBox95.TabStop = false;
            pictureBox95.Tag = "dot";
            // 
            // pictureBox97
            // 
            pictureBox97.Image = Properties.Resources.Pellet;
            pictureBox97.Location = new Point(215, 81);
            pictureBox97.Name = "pictureBox97";
            pictureBox97.Size = new Size(20, 20);
            pictureBox97.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox97.TabIndex = 83;
            pictureBox97.TabStop = false;
            pictureBox97.Tag = "dot";
            // 
            // pictureBox99
            // 
            pictureBox99.Image = Properties.Resources.Pellet;
            pictureBox99.Location = new Point(251, 81);
            pictureBox99.Name = "pictureBox99";
            pictureBox99.Size = new Size(20, 20);
            pictureBox99.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox99.TabIndex = 81;
            pictureBox99.TabStop = false;
            pictureBox99.Tag = "dot";
            // 
            // pictureBox101
            // 
            pictureBox101.Image = Properties.Resources.Pellet;
            pictureBox101.Location = new Point(287, 81);
            pictureBox101.Name = "pictureBox101";
            pictureBox101.Size = new Size(20, 20);
            pictureBox101.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox101.TabIndex = 79;
            pictureBox101.TabStop = false;
            pictureBox101.Tag = "dot";
            // 
            // pictureBox102
            // 
            pictureBox102.Image = Properties.Resources.Pellet;
            pictureBox102.Location = new Point(324, 117);
            pictureBox102.Name = "pictureBox102";
            pictureBox102.Size = new Size(20, 20);
            pictureBox102.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox102.TabIndex = 78;
            pictureBox102.TabStop = false;
            pictureBox102.Tag = "dot";
            // 
            // pictureBox103
            // 
            pictureBox103.Image = Properties.Resources.Pellet;
            pictureBox103.Location = new Point(324, 81);
            pictureBox103.Name = "pictureBox103";
            pictureBox103.Size = new Size(20, 20);
            pictureBox103.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox103.TabIndex = 77;
            pictureBox103.TabStop = false;
            pictureBox103.Tag = "dot";
            // 
            // pictureBox104
            // 
            pictureBox104.Image = Properties.Resources.Pellet;
            pictureBox104.Location = new Point(360, 117);
            pictureBox104.Name = "pictureBox104";
            pictureBox104.Size = new Size(20, 20);
            pictureBox104.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox104.TabIndex = 76;
            pictureBox104.TabStop = false;
            pictureBox104.Tag = "dot";
            // 
            // pictureBox105
            // 
            pictureBox105.Image = Properties.Resources.Pellet;
            pictureBox105.Location = new Point(360, 81);
            pictureBox105.Name = "pictureBox105";
            pictureBox105.Size = new Size(20, 20);
            pictureBox105.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox105.TabIndex = 75;
            pictureBox105.TabStop = false;
            pictureBox105.Tag = "dot";
            // 
            // pictureBox106
            // 
            pictureBox106.Image = Properties.Resources.Pellet;
            pictureBox106.Location = new Point(106, 625);
            pictureBox106.Name = "pictureBox106";
            pictureBox106.Size = new Size(20, 20);
            pictureBox106.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox106.TabIndex = 138;
            pictureBox106.TabStop = false;
            pictureBox106.Tag = "dot";
            // 
            // pictureBox107
            // 
            pictureBox107.Image = Properties.Resources.Pellet;
            pictureBox107.Location = new Point(106, 589);
            pictureBox107.Name = "pictureBox107";
            pictureBox107.Size = new Size(20, 20);
            pictureBox107.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox107.TabIndex = 137;
            pictureBox107.TabStop = false;
            pictureBox107.Tag = "dot";
            // 
            // pictureBox108
            // 
            pictureBox108.Image = Properties.Resources.Pellet;
            pictureBox108.Location = new Point(142, 625);
            pictureBox108.Name = "pictureBox108";
            pictureBox108.Size = new Size(20, 20);
            pictureBox108.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox108.TabIndex = 136;
            pictureBox108.TabStop = false;
            pictureBox108.Tag = "dot";
            // 
            // pictureBox109
            // 
            pictureBox109.Image = Properties.Resources.Pellet;
            pictureBox109.Location = new Point(142, 589);
            pictureBox109.Name = "pictureBox109";
            pictureBox109.Size = new Size(20, 20);
            pictureBox109.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox109.TabIndex = 135;
            pictureBox109.TabStop = false;
            pictureBox109.Tag = "dot";
            // 
            // pictureBox110
            // 
            pictureBox110.Image = Properties.Resources.Pellet;
            pictureBox110.Location = new Point(179, 625);
            pictureBox110.Name = "pictureBox110";
            pictureBox110.Size = new Size(20, 20);
            pictureBox110.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox110.TabIndex = 134;
            pictureBox110.TabStop = false;
            pictureBox110.Tag = "dot";
            // 
            // pictureBox112
            // 
            pictureBox112.Image = Properties.Resources.Pellet;
            pictureBox112.Location = new Point(215, 625);
            pictureBox112.Name = "pictureBox112";
            pictureBox112.Size = new Size(20, 20);
            pictureBox112.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox112.TabIndex = 132;
            pictureBox112.TabStop = false;
            pictureBox112.Tag = "dot";
            // 
            // pictureBox114
            // 
            pictureBox114.Image = Properties.Resources.Pellet;
            pictureBox114.Location = new Point(251, 625);
            pictureBox114.Name = "pictureBox114";
            pictureBox114.Size = new Size(20, 20);
            pictureBox114.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox114.TabIndex = 130;
            pictureBox114.TabStop = false;
            pictureBox114.Tag = "dot";
            // 
            // pictureBox116
            // 
            pictureBox116.Image = Properties.Resources.Pellet;
            pictureBox116.Location = new Point(287, 625);
            pictureBox116.Name = "pictureBox116";
            pictureBox116.Size = new Size(20, 20);
            pictureBox116.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox116.TabIndex = 128;
            pictureBox116.TabStop = false;
            pictureBox116.Tag = "dot";
            // 
            // pictureBox118
            // 
            pictureBox118.Image = Properties.Resources.Pellet;
            pictureBox118.Location = new Point(324, 625);
            pictureBox118.Name = "pictureBox118";
            pictureBox118.Size = new Size(20, 20);
            pictureBox118.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox118.TabIndex = 126;
            pictureBox118.TabStop = false;
            pictureBox118.Tag = "dot";
            // 
            // pictureBox119
            // 
            pictureBox119.Image = Properties.Resources.Pellet;
            pictureBox119.Location = new Point(324, 589);
            pictureBox119.Name = "pictureBox119";
            pictureBox119.Size = new Size(20, 20);
            pictureBox119.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox119.TabIndex = 125;
            pictureBox119.TabStop = false;
            pictureBox119.Tag = "dot";
            // 
            // pictureBox120
            // 
            pictureBox120.Image = Properties.Resources.Pellet;
            pictureBox120.Location = new Point(360, 625);
            pictureBox120.Name = "pictureBox120";
            pictureBox120.Size = new Size(20, 20);
            pictureBox120.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox120.TabIndex = 124;
            pictureBox120.TabStop = false;
            pictureBox120.Tag = "dot";
            // 
            // pictureBox121
            // 
            pictureBox121.Image = Properties.Resources.Pellet;
            pictureBox121.Location = new Point(360, 589);
            pictureBox121.Name = "pictureBox121";
            pictureBox121.Size = new Size(20, 20);
            pictureBox121.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox121.TabIndex = 123;
            pictureBox121.TabStop = false;
            pictureBox121.Tag = "dot";
            // 
            // pictureBox122
            // 
            pictureBox122.Image = Properties.Resources.Pellet;
            pictureBox122.Location = new Point(106, 553);
            pictureBox122.Name = "pictureBox122";
            pictureBox122.Size = new Size(20, 20);
            pictureBox122.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox122.TabIndex = 122;
            pictureBox122.TabStop = false;
            pictureBox122.Tag = "dot";
            // 
            // pictureBox123
            // 
            pictureBox123.Image = Properties.Resources.Pellet;
            pictureBox123.Location = new Point(106, 517);
            pictureBox123.Name = "pictureBox123";
            pictureBox123.Size = new Size(20, 20);
            pictureBox123.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox123.TabIndex = 121;
            pictureBox123.TabStop = false;
            pictureBox123.Tag = "dot";
            // 
            // pictureBox124
            // 
            pictureBox124.Image = Properties.Resources.Pellet;
            pictureBox124.Location = new Point(142, 553);
            pictureBox124.Name = "pictureBox124";
            pictureBox124.Size = new Size(20, 20);
            pictureBox124.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox124.TabIndex = 120;
            pictureBox124.TabStop = false;
            pictureBox124.Tag = "dot";
            // 
            // pictureBox125
            // 
            pictureBox125.Image = Properties.Resources.Pellet;
            pictureBox125.Location = new Point(142, 517);
            pictureBox125.Name = "pictureBox125";
            pictureBox125.Size = new Size(20, 20);
            pictureBox125.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox125.TabIndex = 119;
            pictureBox125.TabStop = false;
            pictureBox125.Tag = "dot";
            // 
            // pictureBox127
            // 
            pictureBox127.Image = Properties.Resources.Pellet;
            pictureBox127.Location = new Point(179, 517);
            pictureBox127.Name = "pictureBox127";
            pictureBox127.Size = new Size(20, 20);
            pictureBox127.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox127.TabIndex = 117;
            pictureBox127.TabStop = false;
            pictureBox127.Tag = "dot";
            // 
            // pictureBox129
            // 
            pictureBox129.Image = Properties.Resources.Pellet;
            pictureBox129.Location = new Point(215, 517);
            pictureBox129.Name = "pictureBox129";
            pictureBox129.Size = new Size(20, 20);
            pictureBox129.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox129.TabIndex = 115;
            pictureBox129.TabStop = false;
            pictureBox129.Tag = "dot";
            // 
            // pictureBox131
            // 
            pictureBox131.Image = Properties.Resources.Pellet;
            pictureBox131.Location = new Point(251, 517);
            pictureBox131.Name = "pictureBox131";
            pictureBox131.Size = new Size(20, 20);
            pictureBox131.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox131.TabIndex = 113;
            pictureBox131.TabStop = false;
            pictureBox131.Tag = "dot";
            // 
            // pictureBox133
            // 
            pictureBox133.Image = Properties.Resources.Pellet;
            pictureBox133.Location = new Point(287, 517);
            pictureBox133.Name = "pictureBox133";
            pictureBox133.Size = new Size(20, 20);
            pictureBox133.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox133.TabIndex = 111;
            pictureBox133.TabStop = false;
            pictureBox133.Tag = "dot";
            // 
            // pictureBox134
            // 
            pictureBox134.Image = Properties.Resources.Pellet;
            pictureBox134.Location = new Point(324, 553);
            pictureBox134.Name = "pictureBox134";
            pictureBox134.Size = new Size(20, 20);
            pictureBox134.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox134.TabIndex = 110;
            pictureBox134.TabStop = false;
            pictureBox134.Tag = "dot";
            // 
            // pictureBox135
            // 
            pictureBox135.Image = Properties.Resources.Pellet;
            pictureBox135.Location = new Point(324, 517);
            pictureBox135.Name = "pictureBox135";
            pictureBox135.Size = new Size(20, 20);
            pictureBox135.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox135.TabIndex = 109;
            pictureBox135.TabStop = false;
            pictureBox135.Tag = "dot";
            // 
            // pictureBox136
            // 
            pictureBox136.Image = Properties.Resources.Pellet;
            pictureBox136.Location = new Point(360, 553);
            pictureBox136.Name = "pictureBox136";
            pictureBox136.Size = new Size(20, 20);
            pictureBox136.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox136.TabIndex = 108;
            pictureBox136.TabStop = false;
            pictureBox136.Tag = "dot";
            // 
            // pictureBox137
            // 
            pictureBox137.Image = Properties.Resources.Pellet;
            pictureBox137.Location = new Point(360, 517);
            pictureBox137.Name = "pictureBox137";
            pictureBox137.Size = new Size(20, 20);
            pictureBox137.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox137.TabIndex = 107;
            pictureBox137.TabStop = false;
            pictureBox137.Tag = "dot";
            // 
            // pictureBox62
            // 
            pictureBox62.Image = Properties.Resources.Pellet;
            pictureBox62.Location = new Point(482, 242);
            pictureBox62.Name = "pictureBox62";
            pictureBox62.Size = new Size(20, 20);
            pictureBox62.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox62.TabIndex = 163;
            pictureBox62.TabStop = false;
            pictureBox62.Tag = "dot";
            // 
            // pictureBox68
            // 
            pictureBox68.Image = Properties.Resources.Pellet;
            pictureBox68.Location = new Point(847, 189);
            pictureBox68.Name = "pictureBox68";
            pictureBox68.Size = new Size(20, 20);
            pictureBox68.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox68.TabIndex = 161;
            pictureBox68.TabStop = false;
            pictureBox68.Tag = "dot";
            // 
            // pictureBox14
            // 
            pictureBox14.Image = Properties.Resources.Pellet;
            pictureBox14.Location = new Point(512, 242);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(20, 20);
            pictureBox14.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox14.TabIndex = 162;
            pictureBox14.TabStop = false;
            pictureBox14.Tag = "dot";
            // 
            // pictureBox16
            // 
            pictureBox16.Image = Properties.Resources.Pellet;
            pictureBox16.Location = new Point(512, 268);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(20, 20);
            pictureBox16.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 162;
            pictureBox16.TabStop = false;
            pictureBox16.Tag = "dot";
            // 
            // pictureBox22
            // 
            pictureBox22.Image = Properties.Resources.Pellet;
            pictureBox22.Location = new Point(482, 268);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new Size(20, 20);
            pictureBox22.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox22.TabIndex = 163;
            pictureBox22.TabStop = false;
            pictureBox22.Tag = "dot";
            // 
            // pictureBox24
            // 
            pictureBox24.Image = Properties.Resources.Pellet;
            pictureBox24.Location = new Point(400, 314);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new Size(20, 20);
            pictureBox24.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox24.TabIndex = 162;
            pictureBox24.TabStop = false;
            pictureBox24.Tag = "dot";
            // 
            // pictureBox27
            // 
            pictureBox27.Image = Properties.Resources.Pellet;
            pictureBox27.Location = new Point(400, 340);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new Size(20, 20);
            pictureBox27.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox27.TabIndex = 162;
            pictureBox27.TabStop = false;
            pictureBox27.Tag = "dot";
            // 
            // pictureBox29
            // 
            pictureBox29.Image = Properties.Resources.Pellet;
            pictureBox29.Location = new Point(400, 370);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new Size(20, 20);
            pictureBox29.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox29.TabIndex = 163;
            pictureBox29.TabStop = false;
            pictureBox29.Tag = "dot";
            // 
            // pictureBox30
            // 
            pictureBox30.Image = Properties.Resources.Pellet;
            pictureBox30.Location = new Point(400, 396);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new Size(20, 20);
            pictureBox30.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox30.TabIndex = 163;
            pictureBox30.TabStop = false;
            pictureBox30.Tag = "dot";
            // 
            // pictureBox39
            // 
            pictureBox39.Image = Properties.Resources.Pellet;
            pictureBox39.Location = new Point(594, 314);
            pictureBox39.Name = "pictureBox39";
            pictureBox39.Size = new Size(20, 20);
            pictureBox39.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox39.TabIndex = 162;
            pictureBox39.TabStop = false;
            pictureBox39.Tag = "dot";
            // 
            // pictureBox41
            // 
            pictureBox41.Image = Properties.Resources.Pellet;
            pictureBox41.Location = new Point(594, 340);
            pictureBox41.Name = "pictureBox41";
            pictureBox41.Size = new Size(20, 20);
            pictureBox41.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox41.TabIndex = 162;
            pictureBox41.TabStop = false;
            pictureBox41.Tag = "dot";
            // 
            // pictureBox47
            // 
            pictureBox47.Image = Properties.Resources.Pellet;
            pictureBox47.Location = new Point(594, 370);
            pictureBox47.Name = "pictureBox47";
            pictureBox47.Size = new Size(20, 20);
            pictureBox47.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox47.TabIndex = 163;
            pictureBox47.TabStop = false;
            pictureBox47.Tag = "dot";
            // 
            // pictureBox49
            // 
            pictureBox49.Image = Properties.Resources.Pellet;
            pictureBox49.Location = new Point(594, 396);
            pictureBox49.Name = "pictureBox49";
            pictureBox49.Size = new Size(20, 20);
            pictureBox49.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox49.TabIndex = 163;
            pictureBox49.TabStop = false;
            pictureBox49.Tag = "dot";
            // 
            // pictureBox51
            // 
            pictureBox51.Image = Properties.Resources.Pellet;
            pictureBox51.Location = new Point(512, 458);
            pictureBox51.Name = "pictureBox51";
            pictureBox51.Size = new Size(20, 20);
            pictureBox51.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox51.TabIndex = 166;
            pictureBox51.TabStop = false;
            pictureBox51.Tag = "dot";
            // 
            // pictureBox53
            // 
            pictureBox53.Image = Properties.Resources.Pellet;
            pictureBox53.Location = new Point(512, 432);
            pictureBox53.Name = "pictureBox53";
            pictureBox53.Size = new Size(20, 20);
            pictureBox53.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox53.TabIndex = 167;
            pictureBox53.TabStop = false;
            pictureBox53.Tag = "dot";
            // 
            // pictureBox64
            // 
            pictureBox64.Image = Properties.Resources.Pellet;
            pictureBox64.Location = new Point(482, 458);
            pictureBox64.Name = "pictureBox64";
            pictureBox64.Size = new Size(20, 20);
            pictureBox64.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox64.TabIndex = 164;
            pictureBox64.TabStop = false;
            pictureBox64.Tag = "dot";
            // 
            // pictureBox66
            // 
            pictureBox66.Image = Properties.Resources.Pellet;
            pictureBox66.Location = new Point(482, 432);
            pictureBox66.Name = "pictureBox66";
            pictureBox66.Size = new Size(20, 20);
            pictureBox66.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox66.TabIndex = 165;
            pictureBox66.TabStop = false;
            pictureBox66.Tag = "dot";
            // 
            // pictureBox79
            // 
            pictureBox79.Image = Properties.Resources.Pellet;
            pictureBox79.Location = new Point(620, 370);
            pictureBox79.Name = "pictureBox79";
            pictureBox79.Size = new Size(20, 20);
            pictureBox79.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox79.TabIndex = 169;
            pictureBox79.TabStop = false;
            pictureBox79.Tag = "dot";
            // 
            // pictureBox81
            // 
            pictureBox81.Image = Properties.Resources.Pellet;
            pictureBox81.Location = new Point(620, 340);
            pictureBox81.Name = "pictureBox81";
            pictureBox81.Size = new Size(20, 20);
            pictureBox81.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox81.TabIndex = 168;
            pictureBox81.TabStop = false;
            pictureBox81.Tag = "dot";
            // 
            // pictureBox83
            // 
            pictureBox83.Image = Properties.Resources.Pellet;
            pictureBox83.Location = new Point(374, 370);
            pictureBox83.Name = "pictureBox83";
            pictureBox83.Size = new Size(20, 20);
            pictureBox83.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox83.TabIndex = 171;
            pictureBox83.TabStop = false;
            pictureBox83.Tag = "dot";
            // 
            // pictureBox85
            // 
            pictureBox85.Image = Properties.Resources.Pellet;
            pictureBox85.Location = new Point(374, 340);
            pictureBox85.Name = "pictureBox85";
            pictureBox85.Size = new Size(20, 20);
            pictureBox85.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox85.TabIndex = 170;
            pictureBox85.TabStop = false;
            pictureBox85.Tag = "dot";
            // 
            // pictureBox94
            // 
            pictureBox94.Image = Properties.Resources.Pellet;
            pictureBox94.Location = new Point(348, 357);
            pictureBox94.Name = "pictureBox94";
            pictureBox94.Size = new Size(20, 20);
            pictureBox94.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox94.TabIndex = 170;
            pictureBox94.TabStop = false;
            pictureBox94.Tag = "dot";
            // 
            // pictureBox96
            // 
            pictureBox96.Image = Properties.Resources.Pellet;
            pictureBox96.Location = new Point(646, 357);
            pictureBox96.Name = "pictureBox96";
            pictureBox96.Size = new Size(20, 20);
            pictureBox96.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox96.TabIndex = 168;
            pictureBox96.TabStop = false;
            pictureBox96.Tag = "dot";
            // 
            // pictureBox98
            // 
            pictureBox98.Image = Properties.Resources.Pellet;
            pictureBox98.Location = new Point(497, 216);
            pictureBox98.Name = "pictureBox98";
            pictureBox98.Size = new Size(20, 20);
            pictureBox98.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox98.TabIndex = 172;
            pictureBox98.TabStop = false;
            pictureBox98.Tag = "dot";
            // 
            // pictureBox100
            // 
            pictureBox100.Image = Properties.Resources.Pellet;
            pictureBox100.Location = new Point(497, 484);
            pictureBox100.Name = "pictureBox100";
            pictureBox100.Size = new Size(20, 20);
            pictureBox100.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox100.TabIndex = 172;
            pictureBox100.TabStop = false;
            pictureBox100.Tag = "dot";
            // 
            // GameTimer
            // 
            GameTimer.Interval = 20;
            GameTimer.Tick += GameTimerEvent;
            // 
            // panelMenu
            // 
            panelMenu.Controls.Add(lblInfo);
            panelMenu.Controls.Add(label1);
            panelMenu.Controls.Add(button1);
            panelMenu.Location = new Point(215, 215);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(579, 358);
            panelMenu.TabIndex = 173;
            // 
            // lblInfo
            // 
            lblInfo.Font = new Font("Broadway", 32F, FontStyle.Bold);
            lblInfo.ForeColor = Color.Yellow;
            lblInfo.ImageAlign = ContentAlignment.TopCenter;
            lblInfo.Location = new Point(3, 224);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new Size(573, 134);
            lblInfo.TabIndex = 2;
            lblInfo.Text = "UP/DOWN/LEFT/RIGHT";
            lblInfo.TextAlign = ContentAlignment.MiddleCenter;
            lblInfo.Click += label2_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Broadway", 32.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Yellow;
            label1.ImageAlign = ContentAlignment.TopCenter;
            label1.Location = new Point(3, 1);
            label1.Name = "label1";
            label1.Size = new Size(573, 72);
            label1.TabIndex = 1;
            label1.Text = "Pac-Man";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.Font = new Font("Bernard MT Condensed", 32.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(145, 99);
            button1.Name = "button1";
            button1.Size = new Size(289, 102);
            button1.TabIndex = 0;
            button1.Text = "Play";
            button1.UseVisualStyleBackColor = true;
            button1.Click += StartButtonClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1014, 736);
            Controls.Add(panelMenu);
            Controls.Add(pictureBox100);
            Controls.Add(pictureBox98);
            Controls.Add(pictureBox83);
            Controls.Add(pictureBox94);
            Controls.Add(pictureBox85);
            Controls.Add(pictureBox79);
            Controls.Add(pictureBox96);
            Controls.Add(pictureBox81);
            Controls.Add(pictureBox51);
            Controls.Add(pictureBox53);
            Controls.Add(pictureBox64);
            Controls.Add(pictureBox66);
            Controls.Add(pictureBox49);
            Controls.Add(pictureBox30);
            Controls.Add(pictureBox22);
            Controls.Add(pictureBox47);
            Controls.Add(pictureBox29);
            Controls.Add(pictureBox62);
            Controls.Add(pictureBox41);
            Controls.Add(pictureBox27);
            Controls.Add(pictureBox16);
            Controls.Add(pictureBox39);
            Controls.Add(pictureBox24);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox68);
            Controls.Add(pictureBox106);
            Controls.Add(pictureBox107);
            Controls.Add(pictureBox108);
            Controls.Add(pictureBox109);
            Controls.Add(pictureBox110);
            Controls.Add(pictureBox112);
            Controls.Add(pictureBox114);
            Controls.Add(pictureBox116);
            Controls.Add(pictureBox118);
            Controls.Add(pictureBox119);
            Controls.Add(pictureBox120);
            Controls.Add(pictureBox121);
            Controls.Add(pictureBox122);
            Controls.Add(pictureBox123);
            Controls.Add(pictureBox124);
            Controls.Add(pictureBox125);
            Controls.Add(pictureBox127);
            Controls.Add(pictureBox129);
            Controls.Add(pictureBox131);
            Controls.Add(pictureBox133);
            Controls.Add(pictureBox134);
            Controls.Add(pictureBox135);
            Controls.Add(pictureBox136);
            Controls.Add(pictureBox137);
            Controls.Add(pictureBox74);
            Controls.Add(pictureBox75);
            Controls.Add(pictureBox76);
            Controls.Add(pictureBox77);
            Controls.Add(pictureBox78);
            Controls.Add(pictureBox80);
            Controls.Add(pictureBox82);
            Controls.Add(pictureBox84);
            Controls.Add(pictureBox86);
            Controls.Add(pictureBox87);
            Controls.Add(pictureBox88);
            Controls.Add(pictureBox89);
            Controls.Add(pictureBox90);
            Controls.Add(pictureBox91);
            Controls.Add(pictureBox92);
            Controls.Add(pictureBox93);
            Controls.Add(pictureBox95);
            Controls.Add(pictureBox97);
            Controls.Add(pictureBox99);
            Controls.Add(pictureBox101);
            Controls.Add(pictureBox102);
            Controls.Add(pictureBox103);
            Controls.Add(pictureBox104);
            Controls.Add(pictureBox105);
            Controls.Add(pictureBox42);
            Controls.Add(pictureBox43);
            Controls.Add(pictureBox44);
            Controls.Add(pictureBox45);
            Controls.Add(pictureBox46);
            Controls.Add(pictureBox48);
            Controls.Add(pictureBox50);
            Controls.Add(pictureBox52);
            Controls.Add(pictureBox54);
            Controls.Add(pictureBox55);
            Controls.Add(pictureBox56);
            Controls.Add(pictureBox57);
            Controls.Add(pictureBox58);
            Controls.Add(pictureBox59);
            Controls.Add(pictureBox60);
            Controls.Add(pictureBox61);
            Controls.Add(pictureBox63);
            Controls.Add(pictureBox65);
            Controls.Add(pictureBox67);
            Controls.Add(pictureBox69);
            Controls.Add(pictureBox70);
            Controls.Add(pictureBox71);
            Controls.Add(pictureBox72);
            Controls.Add(pictureBox73);
            Controls.Add(pictureBox34);
            Controls.Add(pictureBox35);
            Controls.Add(pictureBox36);
            Controls.Add(pictureBox37);
            Controls.Add(pictureBox38);
            Controls.Add(pictureBox40);
            Controls.Add(pictureBox26);
            Controls.Add(pictureBox28);
            Controls.Add(pictureBox31);
            Controls.Add(pictureBox32);
            Controls.Add(pictureBox33);
            Controls.Add(pictureBox18);
            Controls.Add(pictureBox19);
            Controls.Add(pictureBox20);
            Controls.Add(pictureBox21);
            Controls.Add(pictureBox23);
            Controls.Add(pictureBox25);
            Controls.Add(pictureBox17);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox12);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox10);
            Controls.Add(pacman);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "PacMan";
            Load += Form1_Load;
            KeyDown += KeyIsDown;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pacman).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox65).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox75).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox76).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox77).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox78).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox80).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox82).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox84).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox86).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox87).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox88).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox89).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox90).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox91).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox92).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox93).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox95).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox97).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox99).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox101).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox102).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox103).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox104).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox105).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox106).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox107).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox108).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox109).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox110).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox112).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox114).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox116).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox118).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox119).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox120).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox121).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox122).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox123).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox124).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox125).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox127).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox129).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox131).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox133).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox134).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox135).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox136).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox137).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox79).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox81).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox83).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox85).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox94).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox96).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox98).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox100).EndInit();
            panelMenu.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pacman;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private PictureBox pictureBox15;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private PictureBox pictureBox21;
        private PictureBox pictureBox23;
        private PictureBox pictureBox25;
        private PictureBox pictureBox26;
        private PictureBox pictureBox28;
        private PictureBox pictureBox31;
        private PictureBox pictureBox32;
        private PictureBox pictureBox33;
        private PictureBox pictureBox34;
        private PictureBox pictureBox35;
        private PictureBox pictureBox36;
        private PictureBox pictureBox37;
        private PictureBox pictureBox38;
        private PictureBox pictureBox40;
        private PictureBox pictureBox73;
        private PictureBox pictureBox72;
        private PictureBox pictureBox71;
        private PictureBox pictureBox70;
        private PictureBox pictureBox69;
        private PictureBox pictureBox67;
        private PictureBox pictureBox42;
        private PictureBox pictureBox65;
        private PictureBox pictureBox63;
        private PictureBox pictureBox61;
        private PictureBox pictureBox60;
        private PictureBox pictureBox59;
        private PictureBox pictureBox58;
        private PictureBox pictureBox57;
        private PictureBox pictureBox56;
        private PictureBox pictureBox55;
        private PictureBox pictureBox54;
        private PictureBox pictureBox52;
        private PictureBox pictureBox50;
        private PictureBox pictureBox48;
        private PictureBox pictureBox46;
        private PictureBox pictureBox45;
        private PictureBox pictureBox44;
        private PictureBox pictureBox43;
        private PictureBox pictureBox74;
        private PictureBox pictureBox75;
        private PictureBox pictureBox76;
        private PictureBox pictureBox77;
        private PictureBox pictureBox78;
        private PictureBox pictureBox80;
        private PictureBox pictureBox82;
        private PictureBox pictureBox84;
        private PictureBox pictureBox86;
        private PictureBox pictureBox87;
        private PictureBox pictureBox88;
        private PictureBox pictureBox89;
        private PictureBox pictureBox90;
        private PictureBox pictureBox91;
        private PictureBox pictureBox92;
        private PictureBox pictureBox93;
        private PictureBox pictureBox95;
        private PictureBox pictureBox97;
        private PictureBox pictureBox99;
        private PictureBox pictureBox101;
        private PictureBox pictureBox102;
        private PictureBox pictureBox103;
        private PictureBox pictureBox104;
        private PictureBox pictureBox105;
        private PictureBox pictureBox106;
        private PictureBox pictureBox107;
        private PictureBox pictureBox108;
        private PictureBox pictureBox109;
        private PictureBox pictureBox110;
        private PictureBox pictureBox112;
        private PictureBox pictureBox114;
        private PictureBox pictureBox116;
        private PictureBox pictureBox118;
        private PictureBox pictureBox119;
        private PictureBox pictureBox120;
        private PictureBox pictureBox121;
        private PictureBox pictureBox122;
        private PictureBox pictureBox123;
        private PictureBox pictureBox124;
        private PictureBox pictureBox125;
        private PictureBox pictureBox127;
        private PictureBox pictureBox129;
        private PictureBox pictureBox131;
        private PictureBox pictureBox133;
        private PictureBox pictureBox134;
        private PictureBox pictureBox135;
        private PictureBox pictureBox136;
        private PictureBox pictureBox137;
        private PictureBox pictureBox62;
        private PictureBox pictureBox68;
        private PictureBox pictureBox14;
        private PictureBox pictureBox16;
        private PictureBox pictureBox22;
        private PictureBox pictureBox24;
        private PictureBox pictureBox27;
        private PictureBox pictureBox29;
        private PictureBox pictureBox30;
        private PictureBox pictureBox39;
        private PictureBox pictureBox41;
        private PictureBox pictureBox47;
        private PictureBox pictureBox49;
        private PictureBox pictureBox51;
        private PictureBox pictureBox53;
        private PictureBox pictureBox64;
        private PictureBox pictureBox66;
        private PictureBox pictureBox79;
        private PictureBox pictureBox81;
        private PictureBox pictureBox83;
        private PictureBox pictureBox85;
        private PictureBox pictureBox94;
        private PictureBox pictureBox96;
        private PictureBox pictureBox98;
        private PictureBox pictureBox100;
        private System.Windows.Forms.Timer GameTimer;
        private Panel panelMenu;
        private Label label1;
        private Button button1;
        private Label lblInfo;
    }
}
